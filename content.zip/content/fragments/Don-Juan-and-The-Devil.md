---
title: "Don Juan and the Devil"
date: 2022-07-25T20:00:12+04:30

categories:
- Fragments

description: A dialog between Don Juan and the devil. 
tags:
- play
- dialog
- Shaw

keywords: [Don Juan, George Bernard Shaw, Don Juan in Hell]

ShowTOC: false
include_toc: false
draft: false
---

*Don Juan in Hell* is a part of the four-act play, *Man and Superman* written by George Bernard Shaw. It's a debate and a philosophical dialog happening in hell. The participants are Don Juan, his former lover and her father, and the Devil himself. Below is part of the conversation between Don Juan and the Devil. Above all, this part is a parody, mocking the appearances by showing what's really behind the beautiful facades. I think in this day and age the contrast between how people look and how they really are, is even more prevalent. Just take a look at all the people on the Internet. There is indeed a difference between beauty and decoration; which one do we see more often?

> THE DEVIL. [mortified] Senor Don Juan: you are uncivil to my friends.
>
> 
>
> DON JUAN. Pooh! why should I be civil to them or to you? In this Palace of Lies a truth or two will not hurt you. Your friends are all the dullest dogs I know. They are not **beautiful**: they are only **decorated**. They are not **clean**: they are only **shaved and starched**. They are not **dignified**: they are only **fashionably dressed**. They are not **educated** they are only **college passmen**. They are not **religious**: they are only **pewrenters**. They are not **moral**: they are only **conventional**. They are not **virtuous**: they are only **cowardly**. They are not even **vicious**: they are only **"frail."** They are not **artistic**: they are only **lascivious**. They are not **prosperous**: they are only **rich**. They are not **loyal**, they are only **servile**; not **dutiful**, only **sheepish**; not **public spirited**, only **patriotic**; not **courageous**, only **quarrelsome**; not **determined**, only **obstinate**; not **masterful**, only **domineering**; not **self-controlled**, only **obtuse**; not **self-respecting**, only **vain**; not **kind**, only **sentimental**; not **social**, only **gregarious**; not **considerate**, only **polite**; not **intelligent**, only **opinionated**; not **progressive**, only **factious**; not **imaginative**, only **superstitious**; not **just**, only **vindictive**; not **generous**, only **propitiatory**; not **disciplined**, only **cowed**; and not **truthful** at all—**liars every one of them, to the very backbone of their souls**.
